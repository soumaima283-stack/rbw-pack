# Generate unique Minecraft-themed kill sounds using vanilla MC sounds
# Sounds will be layered, pitch-shifted, and mixed to create unique effects

$assetsDir = "$env:APPDATA\.minecraft\assets"
$indexFile = "$assetsDir\indexes\27.json"
$objectsDir = "$assetsDir\objects"
$outputDir = "C:\Users\Administrator\Desktop\resourcepack\assets\minecraft\sounds\custom"
$tempDir = "C:\Users\Administrator\Desktop\resourcepack\_temp_audio"

# Create dirs
New-Item -ItemType Directory -Force -Path $outputDir | Out-Null
New-Item -ItemType Directory -Force -Path $tempDir | Out-Null

# Load asset index
$json = Get-Content $indexFile | ConvertFrom-Json

function Get-MCSound($soundName) {
    $hash = $json.objects.$soundName.hash
    $subdir = $hash.Substring(0,2)
    return "$objectsDir\$subdir\$hash"
}

# Map vanilla sounds
$orb = Get-MCSound "minecraft/sounds/random/orb.ogg"
$levelup = Get-MCSound "minecraft/sounds/random/levelup.ogg"
$successfulHit = Get-MCSound "minecraft/sounds/random/successful_hit.ogg"
$crit1 = Get-MCSound "minecraft/sounds/entity/player/attack/crit1.ogg"
$crit2 = Get-MCSound "minecraft/sounds/entity/player/attack/crit2.ogg"
$strong1 = Get-MCSound "minecraft/sounds/entity/player/attack/strong1.ogg"
$sweep1 = Get-MCSound "minecraft/sounds/entity/player/attack/sweep1.ogg"
$anvilLand = Get-MCSound "minecraft/sounds/random/anvil_land.ogg"
$explode1 = Get-MCSound "minecraft/sounds/random/explode1.ogg"
$explode3 = Get-MCSound "minecraft/sounds/random/explode3.ogg"
$knockback1 = Get-MCSound "minecraft/sounds/entity/player/attack/knockback1.ogg"
$pop = Get-MCSound "minecraft/sounds/random/pop.ogg"
$glass1 = Get-MCSound "minecraft/sounds/random/glass1.ogg"
$click = Get-MCSound "minecraft/sounds/random/click.ogg"
$challengeComplete = Get-MCSound "minecraft/sounds/ui/toast/challenge_complete.ogg"
$hit1 = Get-MCSound "minecraft/sounds/damage/hit1.ogg"
$breakSound = Get-MCSound "minecraft/sounds/random/break.ogg"

Write-Host "=== Generating unique MC-themed kill sounds ===" -ForegroundColor Cyan

# ============================================================
# KILL_CASUAL: Quick satisfying "pop" kill sound
# Mix: pitched-up orb + crit hit + small pop, short and punchy
# ============================================================
Write-Host "[1/4] Generating kill_casual.ogg..." -ForegroundColor Yellow

# Step 1: Pitch up the orb sound (1.3x speed = higher pitch) and trim to 0.4s
ffmpeg -y -i $orb -af "asetrate=44100*1.3,aresample=44100,atrim=0:0.4,afade=out:st=0.25:d=0.15" "$tempDir\orb_pitched.ogg" 2>&1 | Out-Null

# Step 2: Pitch up crit and add a metallic ring
ffmpeg -y -i $crit1 -af "asetrate=44100*1.15,aresample=44100,atrim=0:0.3,afade=out:st=0.15:d=0.15" "$tempDir\crit_pitched.ogg" 2>&1 | Out-Null

# Step 3: Pop sound pitched up slightly
ffmpeg -y -i $pop -af "asetrate=44100*1.2,aresample=44100,atrim=0:0.2" "$tempDir\pop_pitched.ogg" 2>&1 | Out-Null

# Step 4: Layer them all together with volume adjustments
ffmpeg -y -i "$tempDir\orb_pitched.ogg" -i "$tempDir\crit_pitched.ogg" -i "$tempDir\pop_pitched.ogg" `
    -filter_complex "[0:a]volume=0.7[a0];[1:a]volume=0.5,adelay=50|50[a1];[2:a]volume=0.6,adelay=30|30[a2];[a0][a1][a2]amix=inputs=3:duration=shortest,alimiter=limit=0.9,afade=out:st=0.3:d=0.1" `
    -ac 1 -ar 44100 "$outputDir\kill_casual.ogg" 2>&1 | Out-Null

Write-Host "  -> kill_casual.ogg done!" -ForegroundColor Green

# ============================================================
# KILL_SOUND: Standard kill - crunchy and satisfying
# Mix: strong attack + glass break (pitched) + knockback
# ============================================================
Write-Host "[2/4] Generating kill_sound.ogg..." -ForegroundColor Yellow

# Step 1: Strong attack sound with slight pitch down for weight
ffmpeg -y -i $strong1 -af "asetrate=44100*0.9,aresample=44100,atrim=0:0.5,afade=out:st=0.3:d=0.2" "$tempDir\strong_deep.ogg" 2>&1 | Out-Null

# Step 2: Glass break pitched up for a crispy "shatter" effect
ffmpeg -y -i $glass1 -af "asetrate=44100*1.4,aresample=44100,atrim=0:0.35,afade=out:st=0.2:d=0.15,volume=0.4" "$tempDir\glass_crisp.ogg" 2>&1 | Out-Null

# Step 3: Knockback for that extra punch feel
ffmpeg -y -i $knockback1 -af "asetrate=44100*1.1,aresample=44100,atrim=0:0.3,volume=0.5" "$tempDir\knock_punch.ogg" 2>&1 | Out-Null

# Step 4: Successful hit layered in softly
ffmpeg -y -i $successfulHit -af "atrim=0:0.4,afade=out:st=0.25:d=0.15,volume=0.35" "$tempDir\hit_soft.ogg" 2>&1 | Out-Null

# Step 5: Mix it all together
ffmpeg -y -i "$tempDir\strong_deep.ogg" -i "$tempDir\glass_crisp.ogg" -i "$tempDir\knock_punch.ogg" -i "$tempDir\hit_soft.ogg" `
    -filter_complex "[0:a][1:a]amix=inputs=2:duration=first[mix1];[2:a]adelay=80|80[a2d];[3:a]adelay=40|40[a3d];[mix1][a2d][a3d]amix=inputs=3:duration=first,alimiter=limit=0.9,afade=out:st=0.35:d=0.15" `
    -ac 1 -ar 44100 "$outputDir\kill_sound.ogg" 2>&1 | Out-Null

Write-Host "  -> kill_sound.ogg done!" -ForegroundColor Green

# ============================================================
# KILL_FINAL: Final/bed-break kill - dramatic and heavy
# Mix: anvil + explode (pitched down) + sweep + break sound
# ============================================================
Write-Host "[3/4] Generating kill_final.ogg..." -ForegroundColor Yellow

# Step 1: Anvil land as the heavy impact base
ffmpeg -y -i $anvilLand -af "asetrate=44100*0.8,aresample=44100,atrim=0:0.6,afade=out:st=0.35:d=0.25,volume=0.6" "$tempDir\anvil_heavy.ogg" 2>&1 | Out-Null

# Step 2: Small explosion for drama, pitched down
ffmpeg -y -i $explode3 -af "asetrate=44100*0.7,aresample=44100,atrim=0:0.7,afade=in:0:0.05,afade=out:st=0.4:d=0.3,volume=0.35" "$tempDir\explode_rumble.ogg" 2>&1 | Out-Null

# Step 3: Sweep for that whoosh
ffmpeg -y -i $sweep1 -af "asetrate=44100*1.2,aresample=44100,atrim=0:0.3,volume=0.45" "$tempDir\sweep_whoosh.ogg" 2>&1 | Out-Null

# Step 4: Break sound for finality
ffmpeg -y -i $breakSound -af "asetrate=44100*1.1,aresample=44100,atrim=0:0.4,afade=out:st=0.2:d=0.2,volume=0.4" "$tempDir\break_final.ogg" 2>&1 | Out-Null

# Step 5: Layer it all
ffmpeg -y -i "$tempDir\sweep_whoosh.ogg" -i "$tempDir\anvil_heavy.ogg" -i "$tempDir\explode_rumble.ogg" -i "$tempDir\break_final.ogg" `
    -filter_complex "[0:a]adelay=0|0[a0];[1:a]adelay=100|100[a1];[2:a]adelay=50|50[a2];[3:a]adelay=150|150[a3];[a0][a1][a2][a3]amix=inputs=4:duration=longest,alimiter=limit=0.9,afade=out:st=0.5:d=0.2" `
    -ac 1 -ar 44100 "$outputDir\kill_final.ogg" 2>&1 | Out-Null

Write-Host "  -> kill_final.ogg done!" -ForegroundColor Green

# ============================================================
# PENTAKILL: Epic multi-kill celebration
# Mix: challenge_complete + levelup + multiple crits layered + orb cascade
# ============================================================
Write-Host "[4/4] Generating pentakill.ogg..." -ForegroundColor Yellow

# Step 1: Challenge complete as the epic base
ffmpeg -y -i $challengeComplete -af "atrim=0:2.0,afade=out:st=1.5:d=0.5,volume=0.6" "$tempDir\challenge_base.ogg" 2>&1 | Out-Null

# Step 2: Level up pitched slightly for extra sparkle
ffmpeg -y -i $levelup -af "asetrate=44100*1.1,aresample=44100,atrim=0:1.0,afade=out:st=0.7:d=0.3,volume=0.5" "$tempDir\levelup_sparkle.ogg" 2>&1 | Out-Null

# Step 3: Rapid-fire orbs at different pitches for cascade effect
ffmpeg -y -i $orb -af "asetrate=44100*1.0,aresample=44100,atrim=0:0.25,volume=0.3" "$tempDir\orb1.ogg" 2>&1 | Out-Null
ffmpeg -y -i $orb -af "asetrate=44100*1.15,aresample=44100,atrim=0:0.25,volume=0.3" "$tempDir\orb2.ogg" 2>&1 | Out-Null
ffmpeg -y -i $orb -af "asetrate=44100*1.3,aresample=44100,atrim=0:0.25,volume=0.3" "$tempDir\orb3.ogg" 2>&1 | Out-Null
ffmpeg -y -i $orb -af "asetrate=44100*1.5,aresample=44100,atrim=0:0.25,volume=0.3" "$tempDir\orb4.ogg" 2>&1 | Out-Null
ffmpeg -y -i $orb -af "asetrate=44100*1.7,aresample=44100,atrim=0:0.25,volume=0.3" "$tempDir\orb5.ogg" 2>&1 | Out-Null

# Step 4: Crit stacking for that rapid hit feel
ffmpeg -y -i $crit1 -af "asetrate=44100*1.2,aresample=44100,atrim=0:0.2,volume=0.35" "$tempDir\crit_a.ogg" 2>&1 | Out-Null
ffmpeg -y -i $crit2 -af "asetrate=44100*1.3,aresample=44100,atrim=0:0.2,volume=0.35" "$tempDir\crit_b.ogg" 2>&1 | Out-Null

# Step 5: Explosion for the climax
ffmpeg -y -i $explode1 -af "asetrate=44100*0.85,aresample=44100,atrim=0:0.8,afade=in:0:0.05,afade=out:st=0.5:d=0.3,volume=0.3" "$tempDir\explode_epic.ogg" 2>&1 | Out-Null

# Step 6: Mix all into an epic pentakill
ffmpeg -y `
    -i "$tempDir\challenge_base.ogg" `
    -i "$tempDir\levelup_sparkle.ogg" `
    -i "$tempDir\orb1.ogg" `
    -i "$tempDir\orb2.ogg" `
    -i "$tempDir\orb3.ogg" `
    -i "$tempDir\orb4.ogg" `
    -i "$tempDir\orb5.ogg" `
    -i "$tempDir\crit_a.ogg" `
    -i "$tempDir\crit_b.ogg" `
    -i "$tempDir\explode_epic.ogg" `
    -filter_complex "[0:a]volume=0.6[base];[1:a]adelay=200|200,volume=0.5[lvl];[2:a]adelay=100|100[o1];[3:a]adelay=200|200[o2];[4:a]adelay=300|300[o3];[5:a]adelay=400|400[o4];[6:a]adelay=500|500[o5];[7:a]adelay=150|150[c1];[8:a]adelay=350|350[c2];[9:a]adelay=600|600,volume=0.3[exp];[base][lvl][o1][o2][o3][o4][o5][c1][c2][exp]amix=inputs=10:duration=longest,alimiter=limit=0.9,afade=out:st=1.5:d=0.5" `
    -ac 1 -ar 44100 "$outputDir\pentakill.ogg" 2>&1 | Out-Null

Write-Host "  -> pentakill.ogg done!" -ForegroundColor Green

# Cleanup temp files
Write-Host "`nCleaning up temp files..." -ForegroundColor Gray
Remove-Item -Recurse -Force $tempDir

Write-Host "`n=== All 4 sounds generated successfully! ===" -ForegroundColor Cyan
Write-Host "Output: $outputDir" -ForegroundColor White
Write-Host ""
Write-Host "Sounds created:" -ForegroundColor White
Write-Host "  - kill_casual.ogg  (quick satisfying pop + orb + crit)" -ForegroundColor White
Write-Host "  - kill_sound.ogg   (crunchy strong attack + glass shatter)" -ForegroundColor White
Write-Host "  - kill_final.ogg   (dramatic anvil + explosion + sweep)" -ForegroundColor White
Write-Host "  - pentakill.ogg    (epic celebration cascade)" -ForegroundColor White
